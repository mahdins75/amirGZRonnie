const musicList = [
    {
        ID: '1',
        item: 'coldplay',
        genre: 'pop'
    },
    {
        ID: '2',
        item: 'oneD',
        genre: 'contry'
    },
    {
        ID: '3',
        item: 'Queen',
        genre: 'jass'
    },
    {
        ID: "6",
        item: "AA",
        genre: "light"
    },
    {
        ID: "7",
        item: "BB",
        genre: "light 2"
    },
];
module.exports = {musicList};


